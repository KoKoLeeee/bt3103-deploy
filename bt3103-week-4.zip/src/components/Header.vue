<template>
    <div>
        <h1> Jared's Super Tze Char Store</h1>
    </div>
</template>

<script>

</script>

<style scoped>
div {
    background-color: lightblue;
    padding: 10px;
}
h1 {
  text-align: center;
}
</style>