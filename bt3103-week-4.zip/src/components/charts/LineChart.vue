<template>
  <div class="chart">
    <chart></chart>
  </div>
</template>

<script>
import Chart from "./CallAPI.js";

export default {
  components: {
    chart: Chart,
  },
};
</script>

<style>
</style>